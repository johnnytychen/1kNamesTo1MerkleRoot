const crypto = require('crypto');
const fs = require('fs');

// Function to calculate the Merkle Root hash of a list of data
function calculateMerkleRoot(data) {
  const hashes = data.map((item) => crypto.createHash('sha256').update(item).digest('hex'));
  return buildMerkleTree(hashes)[0];
}

// Function to build the Merkle Tree recursively
function buildMerkleTree(hashes) {
  if (hashes.length === 1) {
    return hashes;
  }

  const nextLevelHashes = [];
  for (let i = 0; i < hashes.length; i += 2) {
    const hash1 = hashes[i];
    const hash2 = (i + 1 < hashes.length) ? hashes[i + 1] : hash1;
    const combinedHash = crypto.createHash('sha256').update(hash1 + hash2).digest('hex');
    nextLevelHashes.push(combinedHash);
  }

  return buildMerkleTree(nextLevelHashes);
}

// Read the niceList.json file
const niceListData = fs.readFileSync('/Users/johnnychen/GiftList-main/utils/niceList.json');
const niceList = JSON.parse(niceListData);

// Calculate the Merkle Root of the niceList
const merkleRoot = calculateMerkleRoot(niceList);

// Start the server and listen for client requests
const http = require('http');

const server = http.createServer((req, res) => {
  if (req.method === 'POST') {
    let body = '';
    req.on('data', (data) => {
      body += data;
    });

    req.on('end', () => {
      const requestedName = body.trim();

      // Check if the requested name is on the nice list
      const isNameOnNiceList = niceList.includes(requestedName);

      // Send the response to the client
      res.setHeader('Content-Type', 'application/json');
      res.end(JSON.stringify({ isNameOnNiceList }));
    });
  }
});

const port = 3000;
server.listen(port, () => {
  console.log(`Server is running on port ${port}`);
});
