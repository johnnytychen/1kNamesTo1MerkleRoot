const http = require('http');

// Example usage: Check if a name is on the nice list
function checkNameOnNiceList(name) {
  const postData = name.trim();

  const options = {
    hostname: 'localhost',
    port: 3000,
    path: '/',
    method: 'POST',
    headers: {
      'Content-Type': 'text/plain',
      'Content-Length': postData.length
    }
  };

  const req = http.request(options, (res) => {
    let data = '';
    res.on('data', (chunk) => {
      data += chunk;
    });

    res.on('end', () => {
      const response = JSON.parse(data);
      const isNameOnNiceList = response.isNameOnNiceList;

      if (isNameOnNiceList) {
        console.log(`${name} is on the nice list!`);
      } else {
        console.log(`${name} is not on the nice list.`);
      }
    });
  });

  req.on('error', (error) => {
    console.error(`Error: ${error.message}`);
  });

  req.write(postData);
  req.end();
}

// Example usage: Check if "Sidney Kertzmann" is on the nice list
checkNameOnNiceList("Johnny Chen");