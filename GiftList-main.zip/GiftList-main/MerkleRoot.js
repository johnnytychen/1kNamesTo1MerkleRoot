const crypto = require('crypto');

// Function to calculate the Merkle root
function calculateMerkleRoot(data) {
  if (data.length === 0) {
    throw new Error('Data cannot be empty');
  }

  // Create an array of hashes from the data
  const hashes = data.map(item => crypto.createHash('sha256').update(item).digest('hex'));

  // Recursive function to calculate the Merkle root
  function calculateRoot(hashes) {
    if (hashes.length === 1) {
      return hashes[0];
    }

    const nextLevelHashes = [];
    for (let i = 0; i < hashes.length; i += 2) {
      const combinedHash = crypto.createHash('sha256').update(hashes[i] + hashes[i + 1]).digest('hex');
      nextLevelHashes.push(combinedHash);
    }

    return calculateRoot(nextLevelHashes);
  }

  return calculateRoot(hashes);
}

// Example usage
const fs = require('fs');

// Read the niceList.json file
const niceListData = fs.readFileSync('/Users/johnnychen/GiftList-main/utils/niceList.json');
const niceList = JSON.parse(niceListData);

// Calculate the Merkle Root of the niceList
const merkleRoot = calculateMerkleRoot(niceList);

console.log('Merkle Root:', merkleRoot);
